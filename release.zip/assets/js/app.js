(function () {
'use strict';

/* ============================================================
   国际化
   ============================================================ */
let currentLang = 'zh';

function t(key, ...args) {
  const langDict = (window.I18N_LANGS && window.I18N_LANGS[currentLang]) || {};
  const fallbackDict = (window.I18N_LANGS && window.I18N_LANGS.zh) || {};
  let s = langDict[key];
  if (s == null) s = fallbackDict[key];
  if (s == null) s = key;
  if (args.length) {
    args.forEach((v, i) => {
      s = s.replace(new RegExp('\\{' + i + '\\}', 'g'), String(v));
    });
  }
  return s;
}

function applyI18n() {
  document.documentElement.setAttribute('lang', currentLang === 'en' ? 'en' : 'zh-CN');
  document.title = t('app.title');
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-html]').forEach(el => {
    el.innerHTML = t(el.dataset.i18nHtml);
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = t(el.dataset.i18nTitle);
  });
  const langLabel = document.getElementById('lang-label');
  if (langLabel) langLabel.textContent = currentLang === 'en' ? 'EN' : '中文';
}

/* ============================================================
   媒体类型元信息
   ============================================================ */
const MEDIA_TYPES = {
  image: {
    label: '图片', icon: '🖼️',
    exts: { jpg:'JPG', jpeg:'JPEG', jfif:'JFIF', png:'PNG', gif:'GIF',
            webp:'WebP', bmp:'BMP', svg:'SVG', avif:'AVIF', ico:'ICO' }
  },
  video: {
    label: '视频', icon: '🎬',
    exts: { mp4:'MP4', m4v:'M4V', webm:'WebM', mov:'MOV', ogv:'OGV',
            mpg:'MPG', mpeg:'MPEG', avi:'AVI', wmv:'WMV', flv:'FLV', mkv:'MKV' }
  },
  audio: {
    label: '音频', icon: '🎵',
    exts: { mp3:'MP3', wav:'WAV', m4a:'M4A', aac:'AAC', ogg:'OGG',
            oga:'OGA', flac:'FLAC', opus:'OPUS', wma:'WMA', ape:'APE', amr:'AMR' }
  }
};
const EXT_INDEX = {};
for (const kind of Object.keys(MEDIA_TYPES)) {
  for (const ext of Object.keys(MEDIA_TYPES[kind].exts)) {
    EXT_INDEX[ext] = { kind, label: MEDIA_TYPES[kind].exts[ext] };
  }
}
const ALL_EXTS = Object.keys(EXT_INDEX);
const DEFAULT_ENABLED_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'bmp'];
const TRASH_DIR_NAME = '.gallery-trash';
const TRASH_NAME_RE = /^__T(\d{14})_([a-z0-9]{4})__(.+)$/s;

/* ============================================================
   DOM 引用
   ============================================================ */
const sidebar     = document.getElementById('sidebar');
const resizer     = document.getElementById('resizer');
const pickBtn     = document.getElementById('pick-btn');
const statusEl    = document.getElementById('status');
const treeEl      = document.getElementById('tree');
const treeActions = document.getElementById('tree-actions');
const expandAllBtn   = document.getElementById('expand-all');
const collapseAllBtn = document.getElementById('collapse-all');

const crumbEl    = document.getElementById('crumb');
const headMeta   = document.getElementById('head-meta');
const includeSub = document.getElementById('include-sub');
const selModeBtn = document.getElementById('sel-mode-btn');
const langBtn    = document.getElementById('lang-btn');
const langMenu   = document.getElementById('lang-menu');
const langWrap   = document.getElementById('lang-wrap');

const selbar     = document.getElementById('selbar');
const selCount   = document.getElementById('sel-count');
const selAll     = document.getElementById('sel-all');
const selNone    = document.getElementById('sel-none');
const selRestore = document.getElementById('sel-restore');
const selDelete  = document.getElementById('sel-delete');

const contentEl   = document.getElementById('content');
const grid        = document.getElementById('grid');
const placeholder = document.getElementById('placeholder');

const hoverPreview    = document.getElementById('hover-preview');
const hoverPreviewImg = document.getElementById('hover-preview-img');

const ctxMenu = document.getElementById('ctx-menu');

const lightbox   = document.getElementById('lightbox');
const lbStage    = document.getElementById('lb-stage');
const lbImg      = document.getElementById('lb-img');
const lbVideo    = document.getElementById('lb-video');
const lbAudioWrap= document.getElementById('lb-audio-wrap');
const lbAudio    = document.getElementById('lb-audio');
const lbAudioName= document.getElementById('lb-audio-name');
const lbTitle    = document.getElementById('lb-title');
const lbClose    = document.getElementById('lb-close');
const lbPrev     = document.getElementById('lb-prev');
const lbNext     = document.getElementById('lb-next');
const lbBottom   = document.getElementById('lb-bottom');
const lbSlideshowBtn = document.getElementById('lb-slideshow-btn');
const lbSsIcon       = document.getElementById('lb-ss-icon');

const settingsBtn   = document.getElementById('settings-btn');
const settingsModal = document.getElementById('settings-modal');
const settingsClose = document.getElementById('settings-close');
const settingsReset = document.getElementById('settings-reset');
const delModeSetting = document.getElementById('del-mode-setting');
const slideshowIntervalSetting = document.getElementById('slideshow-interval-setting');

const modalTabs  = settingsModal.querySelectorAll('.tab');
const modalPanes = settingsModal.querySelectorAll('.tab-pane');

const EXT_GRIDS = {
  image: document.getElementById('ext-grid-images'),
  video: document.getElementById('ext-grid-videos'),
  audio: document.getElementById('ext-grid-audios')
};

const themeWrap = document.getElementById('theme-wrap');
const themeBtn  = document.getElementById('theme-btn');
const themeMenu = document.getElementById('theme-menu');

const inputs = {
  hoverPreview:      document.getElementById('set-hover-preview'),
  showExif:          document.getElementById('set-show-exif'),
  thumbRes:          document.getElementById('set-thumb-res'),
  tileSize:          document.getElementById('set-tile-size'),
  hoverZoom:         document.getElementById('set-hover-zoom'),
  hoverDelay:        document.getElementById('set-hover-delay'),
  autoPlayMedia:     document.getElementById('set-auto-play-media'),
  slideshow:         document.getElementById('set-slideshow'),
  slideshowInterval: document.getElementById('set-slideshow-interval'),
  allowDelete:       document.getElementById('set-allow-delete'),
  showTrash:         document.getElementById('set-show-trash'),
  allowRestore:      document.getElementById('set-allow-restore')
};
const outputs = {
  thumbRes:          document.getElementById('out-thumb-res'),
  tileSize:          document.getElementById('out-tile-size'),
  hoverZoom:         document.getElementById('out-hover-zoom'),
  hoverDelay:        document.getElementById('out-hover-delay'),
  slideshowInterval: document.getElementById('out-slideshow-interval')
};
const deleteModeRadios = document.querySelectorAll('input[name="del-mode"]');

/* ============================================================
   设置
   ============================================================ */
const SETTINGS_KEY = 'local-gallery-settings';
const DEFAULT_SETTINGS = {
  theme: 'dark',
  lang: null,
  enabledExts: DEFAULT_ENABLED_EXTS.slice(),
  hoverPreview: true,
  showExif: true,
  thumbRes: 320, tileSize: 150, hoverZoom: 3, hoverDelay: 120,
  autoPlayMedia: false,
  slideshow: false,
  slideshowInterval: 3,
  allowDelete: false, deleteMode: 'trash',
  showTrash: false, allowRestore: true
};

function loadSettings() {
  let parsed = null;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) parsed = JSON.parse(raw);
  } catch (e) {}

  const availableLangs = (window.I18N_LANGS && Object.keys(window.I18N_LANGS)) || ['zh', 'en'];
  const userLangValid = parsed && typeof parsed.lang === 'string' && availableLangs.indexOf(parsed.lang) !== -1;
  const baseLang = userLangValid ? parsed.lang : (typeof detectSystemLang === 'function' ? detectSystemLang() : 'zh');

  if (parsed && typeof parsed === 'object') {
    const merged = Object.assign({}, DEFAULT_SETTINGS, parsed);
    if (!Array.isArray(merged.enabledExts)) {
      merged.enabledExts = DEFAULT_ENABLED_EXTS.slice();
    } else {
      merged.enabledExts = merged.enabledExts.filter(e => ALL_EXTS.includes(e));
    }
    if (!['dark', 'light', 'blue'].includes(merged.theme)) merged.theme = 'dark';
    merged.lang = baseLang;
    if (typeof merged.slideshowInterval !== 'number' || merged.slideshowInterval < 1 || merged.slideshowInterval > 30) {
      merged.slideshowInterval = 3;
    }
    return merged;
  }

  const defaults = Object.assign({}, DEFAULT_SETTINGS);
  defaults.lang = baseLang;
  return defaults;
}

let settings = loadSettings();
currentLang = settings.lang;

function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (e) {}
}
function getMediaKind(fileName) {
  const ext = String(fileName).split('.').pop().toLowerCase();
  const info = EXT_INDEX[ext];
  return info ? info.kind : null;
}
function isMediaEnabled(fileName) {
  const ext = String(fileName).split('.').pop().toLowerCase();
  return settings.enabledExts.includes(ext);
}
function applyTileSize() {
  document.documentElement.style.setProperty('--tile-min', settings.tileSize + 'px');
}

/* ============================================================
   语言切换
   ============================================================ */
function syncLangMenu() {
  langMenu.querySelectorAll('.menu-item').forEach(item => {
    item.classList.toggle('active', item.dataset.lang === currentLang);
  });
}
function applyLanguage(lang) {
  currentLang = (lang === 'en') ? 'en' : 'zh';
  settings.lang = currentLang;
  saveSettings();
  applyI18n();
  syncLangMenu();

  if (rootHandle && treeRoot) {
    renderTree();
    if (selectedNode) renderGrid(selectedNode);
  }
  updateSelectionUI();
  syncSlideshowBtn();
  outputs.slideshowInterval.value = t('set.interval.value', settings.slideshowInterval);
  if (lightbox.classList.contains('open') && currentFiles[currentIndex]) {
    showImage(currentFiles, currentIndex); // 刷新灯箱底部语言
  }
}
langBtn.addEventListener('click', e => {
  e.stopPropagation();
  langMenu.classList.toggle('hidden');
  themeMenu.classList.add('hidden');
});
langMenu.querySelectorAll('.menu-item').forEach(item => {
  item.addEventListener('click', () => {
    applyLanguage(item.dataset.lang);
    langMenu.classList.add('hidden');
  });
});

/* ============================================================
   主题
   ============================================================ */
function applyTheme(name) {
  document.documentElement.setAttribute('data-theme', name);
  settings.theme = name;
  saveSettings();
  syncThemeMenu();
}
function syncThemeMenu() {
  themeMenu.querySelectorAll('.menu-item').forEach(i => {
    i.classList.toggle('active', i.dataset.theme === settings.theme);
  });
}
themeBtn.addEventListener('click', e => {
  e.stopPropagation();
  themeMenu.classList.toggle('hidden');
  langMenu.classList.add('hidden');
});
themeMenu.querySelectorAll('.menu-item').forEach(item => {
  item.addEventListener('click', () => {
    applyTheme(item.dataset.theme);
    themeMenu.classList.add('hidden');
  });
});
document.addEventListener('click', e => {
  if (!themeWrap.contains(e.target)) themeMenu.classList.add('hidden');
  if (!langWrap.contains(e.target)) langMenu.classList.add('hidden');
});

/* ============================================================
   设置面板 Tab
   ============================================================ */
modalTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    modalTabs.forEach(t => t.classList.toggle('active', t === tab));
    modalPanes.forEach(p => p.classList.toggle('hidden', p.dataset.pane !== tab.dataset.tab));
  });
});
function activateTab(name) {
  modalTabs.forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  modalPanes.forEach(p => p.classList.toggle('hidden', p.dataset.pane !== name));
}

/* ============================================================
   媒体类型复选框
   ============================================================ */
function buildExtCheckboxes() {
  for (const kind of Object.keys(MEDIA_TYPES)) {
    const container = EXT_GRIDS[kind];
    container.innerHTML = '';
    const exts = Object.keys(MEDIA_TYPES[kind].exts);
    exts.forEach(ext => {
      const label = document.createElement('label');
      label.className = 'toggle-row';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.id = 'set-ext-' + ext;
      cb.value = ext;
      cb.checked = settings.enabledExts.includes(ext);
      cb.addEventListener('change', onExtToggle);
      label.appendChild(cb);
      label.appendChild(document.createTextNode(' ' + MEDIA_TYPES[kind].exts[ext]));
      container.appendChild(label);
    });
  }
  document.querySelectorAll('[data-ext-group]').forEach(btn => {
    btn.addEventListener('click', () => {
      const kind = btn.dataset.extGroup;
      const all = btn.dataset.extAll === '1';
      const exts = Object.keys(MEDIA_TYPES[kind].exts);
      const set = new Set(settings.enabledExts);
      exts.forEach(ext => { if (all) set.add(ext); else set.delete(ext); });
      settings.enabledExts = [...set].filter(e => ALL_EXTS.includes(e));
      saveSettings();
      syncExtCheckboxes();
      refreshViewAfterExtChange();
    });
  });
}
function onExtToggle() {
  const chosen = [];
  ALL_EXTS.forEach(ext => {
    const cb = document.getElementById('set-ext-' + ext);
    if (cb && cb.checked) chosen.push(ext);
  });
  settings.enabledExts = chosen;
  saveSettings();
  refreshViewAfterExtChange();
}
function syncExtCheckboxes() {
  ALL_EXTS.forEach(ext => {
    const cb = document.getElementById('set-ext-' + ext);
    if (cb) cb.checked = settings.enabledExts.includes(ext);
  });
}
function refreshViewAfterExtChange() {
  if (!rootHandle || !treeRoot) return;
  const wasSelected = selectedNode;
  const wasTrash = wasSelected && wasSelected.isTrash;
  updateAllTotals(treeRoot);
  renderTree();
  if (wasTrash) selectTrashNode();
  else if (wasSelected) {
    if (wasSelected._row) wasSelected._row.classList.add('selected');
    selectedNode = wasSelected;
    renderGrid(wasSelected);
  } else selectNode(treeRoot);
}

/* ============================================================
   设置同步 UI
   ============================================================ */
function syncSettingsUI() {
  inputs.hoverPreview.checked = !!settings.hoverPreview;
  inputs.showExif.checked = !!settings.showExif;
  inputs.thumbRes.value = settings.thumbRes;
  outputs.thumbRes.value = settings.thumbRes + ' px';
  inputs.tileSize.value = settings.tileSize;
  outputs.tileSize.value = settings.tileSize + ' px';
  inputs.hoverZoom.value = settings.hoverZoom;
  outputs.hoverZoom.value = Number(settings.hoverZoom).toFixed(1) + '×';
  inputs.hoverDelay.value = settings.hoverDelay;
  outputs.hoverDelay.value = settings.hoverDelay + ' ms';
  inputs.autoPlayMedia.checked = !!settings.autoPlayMedia;
  inputs.slideshow.checked = !!settings.slideshow;
  inputs.slideshowInterval.value = settings.slideshowInterval;
  outputs.slideshowInterval.value = t('set.interval.value', settings.slideshowInterval);
  inputs.allowDelete.checked = !!settings.allowDelete;
  inputs.showTrash.checked = !!settings.showTrash;
  inputs.allowRestore.checked = !!settings.allowRestore;
  deleteModeRadios.forEach(r => { r.checked = r.value === settings.deleteMode; });
  updateDeleteSettingsUI();
  syncExtCheckboxes();
  syncThemeMenu();
  syncLangMenu();
  syncSlideshowBtn();
}
function updateDeleteSettingsUI() {
  delModeSetting.classList.toggle('dim', !settings.allowDelete);
  deleteModeRadios.forEach(r => { r.disabled = !settings.allowDelete; });
  slideshowIntervalSetting.classList.toggle('dim', !settings.slideshow);
  inputs.slideshowInterval.disabled = !settings.slideshow;
}

inputs.hoverPreview.addEventListener('change', e => {
  settings.hoverPreview = e.target.checked;
  saveSettings();
  if (!settings.hoverPreview) hideHoverPreview();
});
inputs.showExif.addEventListener('change', e => {
  settings.showExif = e.target.checked;
  saveSettings();
  if (lightbox.classList.contains('open') && currentFiles[currentIndex]) {
    showImage(currentFiles, currentIndex);
  }
});
inputs.thumbRes.addEventListener('input', e => {
  outputs.thumbRes.value = e.target.value + ' px';
});
inputs.thumbRes.addEventListener('change', e => {
  settings.thumbRes = Number(e.target.value);
  saveSettings();
  thumbCache.clear();
  if (selectedNode) renderGrid(selectedNode);
});
inputs.tileSize.addEventListener('input', e => {
  settings.tileSize = Number(e.target.value);
  outputs.tileSize.value = settings.tileSize + ' px';
  applyTileSize();
  saveSettings();
});
inputs.hoverZoom.addEventListener('input', e => {
  settings.hoverZoom = Number(e.target.value);
  outputs.hoverZoom.value = Number(settings.hoverZoom).toFixed(1) + '×';
  saveSettings();
});
inputs.hoverDelay.addEventListener('input', e => {
  settings.hoverDelay = Number(e.target.value);
  outputs.hoverDelay.value = settings.hoverDelay + ' ms';
  saveSettings();
});
inputs.autoPlayMedia.addEventListener('change', e => {
  settings.autoPlayMedia = e.target.checked;
  saveSettings();
});
inputs.slideshow.addEventListener('change', e => {
  setSlideshow(e.target.checked);
});
inputs.slideshowInterval.addEventListener('input', e => {
  settings.slideshowInterval = Number(e.target.value);
  outputs.slideshowInterval.value = t('set.interval.value', settings.slideshowInterval);
  saveSettings();
});
inputs.slideshowInterval.addEventListener('change', () => {
  if (lightbox.classList.contains('open')) scheduleSlideshow();
});
inputs.allowDelete.addEventListener('change', e => {
  settings.allowDelete = e.target.checked;
  saveSettings();
  updateDeleteSettingsUI();
  updateSelectionUI();
});
inputs.showTrash.addEventListener('change', e => {
  settings.showTrash = e.target.checked;
  saveSettings();
  if (rootHandle) {
    renderTree();
    if (!settings.showTrash && selectedNode && selectedNode.isTrash && treeRoot) {
      selectNode(treeRoot);
    }
  }
});
inputs.allowRestore.addEventListener('change', e => {
  settings.allowRestore = e.target.checked;
  saveSettings();
  updateSelectionUI();
});
deleteModeRadios.forEach(r => {
  r.addEventListener('change', e => {
    if (!e.target.checked) return;
    settings.deleteMode = e.target.value;
    saveSettings();
    updateSelectionUI();
  });
});

settingsBtn.addEventListener('click', () => {
  hideHoverPreview();
  syncSettingsUI();
  activateTab('display');
  settingsModal.classList.add('open');
});
settingsClose.addEventListener('click', () => settingsModal.classList.remove('open'));
settingsModal.addEventListener('click', e => {
  if (e.target === settingsModal) settingsModal.classList.remove('open');
});
settingsReset.addEventListener('click', () => {
  const sysLang = (typeof detectSystemLang === 'function') ? detectSystemLang() : 'zh';
  settings = Object.assign({}, DEFAULT_SETTINGS);
  settings.enabledExts = DEFAULT_ENABLED_EXTS.slice();
  settings.lang = sysLang;
  currentLang = sysLang;
  saveSettings();
  applyTheme('dark');
  applyI18n();
  syncLangMenu();
  syncSettingsUI();
  applyTileSize();
  thumbCache.clear();
  updateSelectionUI();
  refreshViewAfterExtChange();
  if (lightbox.classList.contains('open') && currentFiles[currentIndex]) showImage(currentFiles, currentIndex);
});

/* ============================================================
   EXIF 解析器
   ============================================================ */
async function getExifData(fileObj) {
  if (!fileObj.name.toLowerCase().match(/\.(jpg|jpeg)$/)) return null;
  try {
    // 获取原生 File 对象
    const file = await fileObj.fileHandle.getFile();
    // 读前 256KB，确保能覆盖到所有的 EXIF 头部信息
    const buffer = await file.slice(0, 256 * 1024).arrayBuffer();
    const dataView = new DataView(buffer);
    
    // 检查 JPEG SOI
    if (dataView.getUint16(0) !== 0xFFD8) return null;
    
    let offset = 2;
    let exifOffset = -1;
    // 寻找 APP1 (0xFFE1) 标记
    while (offset < dataView.byteLength) {
      const marker = dataView.getUint16(offset);
      if (marker === 0xFFE1) {
        if (dataView.getUint32(offset + 4) === 0x45786966) { // 'Exif'
          exifOffset = offset + 10;
          break;
        }
      }
      if ((marker & 0xFF00) !== 0xFF00) break;
      offset += dataView.getUint16(offset + 2) + 2;
    }
    if (exifOffset === -1) return null;

    const littleEndian = dataView.getUint16(exifOffset) === 0x4949; // II = 0x4949, MM = 0x4D4D
    const tags = {};
    
    // 定义了需要读取的标签
    const tagNames = {
      0x010F: 'Make',
      0x0110: 'Model',
      0x8769: 'ExifIFDPointer', // 指向子 IFD 的指针
      0x9003: 'DateTimeOriginal',
      0x829D: 'FNumber',
      0x829A: 'ExposureTime',
      0x8827: 'ISO',
      0x920A: 'FocalLength'
    };

    function readTags(startOffset) {
      const numEntries = dataView.getUint16(startOffset, littleEndian);
      let exifSubIFDOffset = null;
      
      for (let i = 0; i < numEntries; i++) {
        const entryOffset = startOffset + 2 + (i * 12);
        const tag = dataView.getUint16(entryOffset, littleEndian);
        
        // 记录子 IFD 的偏移量
        if (tag === 0x8769) {
           const type = dataView.getUint16(entryOffset + 2, littleEndian);
           if (type === 4) { // LONG
              exifSubIFDOffset = dataView.getUint32(entryOffset + 8, littleEndian);
           } else if (type === 3) { // SHORT
              exifSubIFDOffset = dataView.getUint16(entryOffset + 8, littleEndian);
           }
        }

        if (tagNames[tag] && tag !== 0x8769) {
          const type = dataView.getUint16(entryOffset + 2, littleEndian);
          const count = dataView.getUint32(entryOffset + 4, littleEndian);
          const valueOffset = dataView.getUint32(entryOffset + 8, littleEndian);
          
          if (type === 2) { // ASCII String
            let str = '';
            const start = count > 4 ? exifOffset + valueOffset : entryOffset + 8;
            for (let j = 0; j < count - 1; j++) str += String.fromCharCode(dataView.getUint8(start + j));
            tags[tagNames[tag]] = str.trim();
          } else if (type === 3) { // SHORT
            tags[tagNames[tag]] = dataView.getUint16(entryOffset + 8, littleEndian);
          } else if (type === 4) { // LONG
            tags[tagNames[tag]] = dataView.getUint32(entryOffset + 8, littleEndian);
          } else if (type === 5) { // RATIONAL
            const num = dataView.getUint32(exifOffset + valueOffset, littleEndian);
            const den = dataView.getUint32(exifOffset + valueOffset + 4, littleEndian);
            tags[tagNames[tag]] = den === 0 ? 0 : num / den;
          }
        }
      }
      
      const nextIfdOffset = dataView.getUint32(startOffset + 2 + numEntries * 12, littleEndian);
      return { nextIfdOffset, exifSubIFDOffset };
    }

    // 1. 解析主 IFD (IFD0)
    const ifd0Res = readTags(exifOffset + dataView.getUint32(exifOffset + 4, littleEndian));
    
    // 2. 解析 Exif SubIFD (光圈、快门等核心数据在这里)
    if (ifd0Res.exifSubIFDOffset) {
      readTags(exifOffset + ifd0Res.exifSubIFDOffset);
    }
    
    // 3. 解析缩略图 IFD1 (可选)
    if (ifd0Res.nextIfdOffset) {
      readTags(exifOffset + ifd0Res.nextIfdOffset);
    }

    return tags;
  } catch (e) {
    console.error('EXIF parse error:', e);
    return null;
  }
}


/* ============================================================
   文件基础信息回退（日期、大小、类型）
   ============================================================ */
function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
function formatDate(timestamp) {
  if (!timestamp) return '';
  const d = new Date(timestamp);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
async function getFileInfoHtml(fileObj) {
  try {
    const f = await fileObj.fileHandle.getFile();
    const sizeStr = formatBytes(f.size);
    const dateStr = formatDate(f.lastModified);
    const ext = fileObj.name.split('.').pop().toUpperCase();
    return `<span style="color:rgba(255,255,255,.6);letter-spacing:0.5px">📅 ${dateStr} &nbsp;·&nbsp; 📦 ${sizeStr} &nbsp;·&nbsp; 📄 ${ext}</span>`;
  } catch (e) {
    return '';
  }
}


/* ============================================================
   全局状态
   ============================================================ */
let treeRoot = null;
let selectedNode = null;
let currentFiles = [];
let currentIndex = -1;
let renderToken = 0;
let currentObserver = null;
const thumbCache = new Map();
const previewUrlCache = new Map();
let rootHandle = null;
let trashDirHandle = null;
let viewMode = 'normal';

const trashNode = {
  name: '', isTrash: true, path: TRASH_DIR_NAME,
  parent: null, children: [], files: [], expanded: false, _row: null
};
const selectedPaths = new Set();
let selectionMode = false;

/* ============================================================
   分栏拖动
   ============================================================ */
const DEFAULT_SIDEBAR_W = 290;
const savedW = parseInt(localStorage.getItem('gallery-sidebar-w') || '', 10);
if (savedW >= 180 && savedW <= 640) sidebar.style.width = savedW + 'px';
let resizing = false, resizeStartX = 0, resizeStartW = 0;
resizer.addEventListener('mousedown', e => {
  e.preventDefault();
  resizing = true;
  resizeStartX = e.clientX;
  resizeStartW = sidebar.offsetWidth;
  document.body.classList.add('is-resizing');
  hideHoverPreview(); hideCtxMenu();
});
window.addEventListener('mousemove', e => {
  if (!resizing) return;
  const w = Math.max(180, Math.min(640, resizeStartW + (e.clientX - resizeStartX)));
  sidebar.style.width = w + 'px';
});
window.addEventListener('mouseup', () => {
  if (!resizing) return;
  resizing = false;
  document.body.classList.remove('is-resizing');
  localStorage.setItem('gallery-sidebar-w', String(sidebar.offsetWidth));
});
resizer.addEventListener('dblclick', () => {
  sidebar.style.width = DEFAULT_SIDEBAR_W + 'px';
  localStorage.setItem('gallery-sidebar-w', String(DEFAULT_SIDEBAR_W));
});

/* ============================================================
   悬停预览
   ============================================================ */
let hoverTimer = null, hoverTarget = null, previewToken = 0;
function clearPreviewUrlCache() {
  for (const url of previewUrlCache.values()) URL.revokeObjectURL(url);
  previewUrlCache.clear();
}
async function getPreviewUrl(file) {
  const key = file.path;
  if (previewUrlCache.has(key)) return previewUrlCache.get(key);
  const f = await file.fileHandle.getFile();
  const url = URL.createObjectURL(f);
  if (previewUrlCache.size >= 40) {
    const firstKey = previewUrlCache.keys().next().value;
    URL.revokeObjectURL(previewUrlCache.get(firstKey));
    previewUrlCache.delete(firstKey);
  }
  previewUrlCache.set(key, url);
  return url;
}
function hideHoverPreview() {
  if (hoverTimer) { clearTimeout(hoverTimer); hoverTimer = null; }
  hoverTarget = null; previewToken++;
  hoverPreview.classList.remove('show');
  hoverPreviewImg.removeAttribute('src');
}
function scheduleHoverPreview(item) {
  if (selectionMode) return;
  if (!settings.hoverPreview) return;
  if (!item._file) return;
  if (getMediaKind(item._file.name) !== 'image') return;
  if (hoverTimer) { clearTimeout(hoverTimer); hoverTimer = null; }
  hoverTarget = item;
  if (settings.hoverDelay <= 0) { showHoverPreview(item); return; }
  hoverTimer = setTimeout(() => { hoverTimer = null; showHoverPreview(item); }, settings.hoverDelay);
}
function showHoverPreview(item) {
  if (selectionMode || hoverTarget !== item) return;
  if (!settings.hoverPreview) return;
  const file = item._file;
  if (!file || getMediaKind(file.name) !== 'image') return;
  const rect = item.getBoundingClientRect();
  if (rect.width === 0) return;
  if (rect.bottom < 0 || rect.top > window.innerHeight) return;
  const pad = 8;
  let tw = rect.width * settings.hoverZoom;
  let th = rect.height * settings.hoverZoom;
  const k = Math.min(1, (window.innerWidth - pad * 2) / tw, (window.innerHeight - pad * 2) / th);
  tw = Math.round(tw * k); th = Math.round(th * k);
  let left = rect.left + rect.width / 2 - tw / 2;
  let top  = rect.top + rect.height / 2 - th / 2;
  left = Math.max(pad, Math.min(left, window.innerWidth - tw - pad));
  top  = Math.max(pad, Math.min(top, window.innerHeight - th - pad));
  hoverPreview.style.width  = tw + 'px';
  hoverPreview.style.height = th + 'px';
  hoverPreview.style.left   = Math.round(left) + 'px';
  hoverPreview.style.top    = Math.round(top) + 'px';
  hoverPreview.classList.add('show');
  const cachedThumb = thumbCache.get(file.path);
  if (cachedThumb) hoverPreviewImg.src = cachedThumb;
  else hoverPreviewImg.removeAttribute('src');
  const token = ++previewToken;
  getPreviewUrl(file).then(url => {
    if (token !== previewToken) return;
    hoverPreviewImg.src = url;
  }).catch(() => {});
}
grid.addEventListener('mouseover', e => {
  const item = e.target.closest('.thumb-item');
  if (!item || item === hoverTarget) return;
  scheduleHoverPreview(item);
});
grid.addEventListener('mouseout', e => {
  const item = e.target.closest('.thumb-item');
  if (!item) return;
  const to = e.relatedTarget;
  if (to && item.contains(to)) return;
  hideHoverPreview();
});
contentEl.addEventListener('scroll', hideHoverPreview, { passive: true });
window.addEventListener('resize', hideHoverPreview);

/* ============================================================
   目录树
   ============================================================ */
let scannedDirs = 0;
async function buildTree(dirHandle, name, path, depth) {
  scannedDirs++;
  statusEl.textContent = t('status.scanning', scannedDirs);
  const node = { name, path, depth, dirHandle, files: [], children: [], total: 0, expanded: false, parent: null };
  for await (const entry of dirHandle.values()) {
    if (entry.kind === 'file') {
      const ext = entry.name.split('.').pop().toLowerCase();
      if (EXT_INDEX[ext]) {
        node.files.push({
          fileHandle: entry, name: entry.name,
          path: path ? path + '/' + entry.name : entry.name,
          dirPath: path, parentHandle: dirHandle, parentNode: node
        });
      }
    } else if (entry.kind === 'directory') {
      if (depth === 0 && entry.name === TRASH_DIR_NAME) continue;
      const child = await buildTree(entry, entry.name,
        path ? path + '/' + entry.name : entry.name, depth + 1);
      child.parent = node;
      node.children.push(child);
    }
  }
  node.files.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN', { numeric: true }));
  node.children.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN', { numeric: true }));
  node.total = 0;
  return node;
}
function updateAllTotals(node) {
  let n = 0;
  for (const f of node.files) if (isMediaEnabled(f.name)) n++;
  for (const c of node.children) n += updateAllTotals(c);
  node.total = n;
  return n;
}
function renderTree() {
  treeEl.innerHTML = '';
  if (treeRoot) treeEl.appendChild(buildTreeEl(treeRoot));
  if (settings.showTrash && rootHandle) {
    const sep = document.createElement('div');
    sep.className = 'tree-sep';
    treeEl.appendChild(sep);
    treeEl.appendChild(buildTrashRow());
  }
}
function buildTrashRow() {
  const row = document.createElement('div');
  row.className = 'tree-row trash-row';
  row.style.paddingLeft = '8px';
  const icon = document.createElement('span');
  icon.textContent = '🗑';
  icon.style.cssText = 'flex:0 0 14px;text-align:center;font-size:12px;';
  const nameEl = document.createElement('span');
  nameEl.className = 'node-name';
  nameEl.textContent = t('tree.trash');
  row.append(icon, nameEl);
  trashNode._row = row;
  row.addEventListener('click', selectTrashNode);
  return row;
}
function selectTrashNode() {
  hideHoverPreview(); hideCtxMenu();
  if (selectedNode && selectedNode._row) selectedNode._row.classList.remove('selected');
  selectedNode = trashNode;
  if (trashNode._row) trashNode._row.classList.add('selected');
  renderGrid(trashNode);
}
function buildTreeEl(node) {
  const wrap = document.createElement('div');
  wrap.className = 'tree-node';
  const row = document.createElement('div');
  row.className = 'tree-row';
  if (node.total === 0) row.classList.add('empty-node');
  row.style.paddingLeft = (node.depth * 14 + 8) + 'px';
  node._row = row;
  const toggle = document.createElement('span');
  toggle.className = 'toggle';
  toggle.textContent = node.children.length ? (node.expanded ? '▾' : '▸') : '';
  node._toggle = toggle;
  const nameEl = document.createElement('span');
  nameEl.className = 'node-name';
  nameEl.textContent = node.name || t('tree.root');
  nameEl.title = node.path || node.name;
  const countEl = document.createElement('span');
  countEl.className = 'node-count';
  countEl.textContent = node.total;
  node._countEl = countEl;
  row.append(toggle, nameEl, countEl);
  wrap.appendChild(row);
  const childrenWrap = document.createElement('div');
  childrenWrap.className = 'tree-children' + (node.expanded ? '' : ' hidden');
  node._childrenEl = childrenWrap;
  for (const child of node.children) childrenWrap.appendChild(buildTreeEl(child));
  wrap.appendChild(childrenWrap);
  row.addEventListener('click', e => {
    if (e.target === toggle && node.children.length) { toggleExpand(node); return; }
    selectNode(node);
  });
  return wrap;
}
function toggleExpand(node) {
  node.expanded = !node.expanded;
  if (node._childrenEl) node._childrenEl.classList.toggle('hidden', !node.expanded);
  if (node._toggle) node._toggle.textContent = node.children.length ? (node.expanded ? '▾' : '▸') : '';
}
function selectNode(node) {
  hideHoverPreview(); hideCtxMenu();
  if (selectedNode && selectedNode._row) selectedNode._row.classList.remove('selected');
  selectedNode = node;
  let p = node.parent;
  while (p) { if (!p.expanded) toggleExpand(p); p = p.parent; }
  if (node.children.length && !node.expanded) toggleExpand(node);
  if (node._row) node._row.classList.add('selected');
  renderGrid(node);
}
function collectAllFiles(node, out = []) {
  out.push(...node.files);
  for (const c of node.children) collectAllFiles(c, out);
  return out;
}
function recomputeTotals(node) {
  let n = 0;
  for (const f of node.files) if (isMediaEnabled(f.name)) n++;
  for (const c of node.children) n += recomputeTotals(c);
  node.total = n;
  return n;
}
function refreshTreeCounts(node) {
  if (node._countEl) node._countEl.textContent = node.total;
  if (node._row) node._row.classList.toggle('empty-node', node.total === 0);
  node.children.forEach(refreshTreeCounts);
}
async function rebuildTree() {
  if (!rootHandle) return;
  const prevPath = selectedNode && !selectedNode.isTrash ? selectedNode.path : null;
  const wasTrash = selectedNode && selectedNode.isTrash;
  scannedDirs = 0;
  treeRoot = await buildTree(rootHandle, rootHandle.name, '', 0);
  updateAllTotals(treeRoot);
  treeRoot.expanded = true;
  renderTree();
  if (wasTrash && settings.showTrash) selectTrashNode();
  else if (prevPath) {
    const found = findNodeByPath(treeRoot, prevPath);
    selectNode(found || treeRoot);
  } else selectNode(treeRoot);
}
function findNodeByPath(node, path) {
  if (node.path === path) return node;
  for (const c of node.children) {
    const r = findNodeByPath(c, path);
    if (r) return r;
  }
  return null;
}

/* ============================================================
   选择模式
   ============================================================ */
function updateSelectionUI() {
  const n = selectedPaths.size;
  const isTrash = viewMode === 'trash';
  selCount.textContent = t('sel.count', n);
  selbar.classList.toggle('hidden', !selectionMode);
  if (settings.allowDelete) {
    selDelete.classList.remove('hidden');
    selDelete.disabled = n === 0;
    selDelete.textContent = isTrash
      ? t('sel.permanentDelete')
      : (settings.deleteMode === 'trash' ? t('sel.moveToTrash') : t('sel.delete'));
  } else selDelete.classList.add('hidden');
  if (isTrash && settings.allowRestore) {
    selRestore.classList.remove('hidden');
    selRestore.disabled = n === 0;
  } else selRestore.classList.add('hidden');
  selModeBtn.classList.toggle('active', selectionMode);
  selModeBtn.textContent = selectionMode ? t('btn.exitSelect') : t('btn.select');
  grid.classList.toggle('selecting', selectionMode);
}
function exitSelectionMode() {
  selectionMode = false;
  selectedPaths.clear();
  document.querySelectorAll('.thumb-item').forEach(el => {
    if (el._check) el._check.checked = false;
    el.classList.remove('selected');
  });
  updateSelectionUI();
}
function resetSelectionSilently() {
  selectionMode = false;
  selectedPaths.clear();
  updateSelectionUI();
}
selModeBtn.addEventListener('click', () => {
  if (selectionMode) exitSelectionMode();
  else { selectionMode = true; hideHoverPreview(); updateSelectionUI(); }
});
selAll.addEventListener('click', () => {
  selectionMode = true;
  currentFiles.forEach(f => selectedPaths.add(f.path));
  document.querySelectorAll('.thumb-item').forEach(el => {
    if (el._file && selectedPaths.has(el._file.path)) {
      if (el._check) el._check.checked = true;
      el.classList.add('selected');
    }
  });
  hideHoverPreview(); updateSelectionUI();
});
selNone.addEventListener('click', exitSelectionMode);
selRestore.addEventListener('click', () => {
  const list = currentFiles.filter(f => selectedPaths.has(f.path));
  restoreTrashItems(list);
});
selDelete.addEventListener('click', () => {
  const list = currentFiles.filter(f => selectedPaths.has(f.path));
  if (viewMode === 'trash') purgeTrashItems(list);
  else deleteFiles(list);
});

/* ============================================================
   写权限
   ============================================================ */
async function ensureWritePermission(dirHandle) {
  const opts = { mode: 'readwrite' };
  try {
    if (await dirHandle.queryPermission(opts) === 'granted') return true;
    if (await dirHandle.requestPermission(opts) === 'granted') return true;
  } catch (e) { console.warn('Permission request failed', e); }
  return false;
}

/* ============================================================
   回收站
   ============================================================ */
function formatTimestampCompact(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function parseTrashTimestamp(s) {
  const y = +s.slice(0,4), mo = +s.slice(4,6)-1, d = +s.slice(6,8);
  const h = +s.slice(8,10), mi = +s.slice(10,12), se = +s.slice(12,14);
  return new Date(y, mo, d, h, mi, se).getTime();
}
async function getUniqueName(dir, desired) {
  const dot = desired.lastIndexOf('.');
  const base = dot > 0 ? desired.slice(0, dot) : desired;
  const ext  = dot > 0 ? desired.slice(dot) : '';
  let name = desired, i = 1;
  while (i < 1000) {
    try { await dir.getFileHandle(name); name = `${base}_${i}${ext}`; i++; }
    catch { return name; }
  }
  return `${base}_${Date.now()}${ext}`;
}
async function getTrashDir(create = true) {
  if (trashDirHandle) return trashDirHandle;
  if (!rootHandle) return null;
  const granted = await ensureWritePermission(rootHandle);
  if (!granted) return null;
  try {
    trashDirHandle = await rootHandle.getDirectoryHandle(TRASH_DIR_NAME, { create });
    return trashDirHandle;
  } catch (e) {
    if (create) console.error('Failed to create trash folder', e);
    return null;
  }
}
async function moveToTrash(file, trashDir) {
  const blob = await file.fileHandle.getFile();
  let dir = trashDir;
  if (file.dirPath) {
    for (const part of file.dirPath.split('/')) {
      dir = await dir.getDirectoryHandle(part, { create: true });
    }
  }
  const ts = formatTimestampCompact(new Date());
  const rand = Math.random().toString(36).slice(2, 6).padEnd(4, '0');
  const desired = `__T${ts}_${rand}__${file.name}`;
  const finalName = await getUniqueName(dir, desired);
  const fh = await dir.getFileHandle(finalName, { create: true });
  const w = await fh.createWritable();
  await w.write(blob);
  await w.close();
  await file.parentHandle.removeEntry(file.name);
}
async function scanTrash(trashDir) {
  const items = [];
  async function walk(dir, relPath) {
    for await (const entry of dir.values()) {
      if (entry.kind === 'file') {
        const ext = entry.name.split('.').pop().toLowerCase();
        if (!EXT_INDEX[ext]) continue;
        const m = entry.name.match(TRASH_NAME_RE);
        let originalName = null, originalRelPath = null, deletedAt = 0;
        if (m) {
          deletedAt = parseTrashTimestamp(m[1]);
          originalName = m[3];
          originalRelPath = relPath ? relPath + '/' + originalName : originalName;
        }
        items.push({
          fileHandle: entry, name: entry.name,
          path: TRASH_DIR_NAME + '/' + (relPath ? relPath + '/' : '') + entry.name,
          trashName: entry.name, trashRelPath: relPath,
          originalName, originalRelPath, deletedAt,
          restorable: !!originalRelPath, parentHandle: dir
        });
      } else if (entry.kind === 'directory') {
        await walk(entry, relPath ? relPath + '/' + entry.name : entry.name);
      }
    }
  }
  await walk(trashDir, '');
  return items;
}
async function restoreTrashItems(items) {
  if (!settings.allowRestore) { alert(t('alert.restoreDisabled')); return; }
  const valid = items.filter(i => i.restorable);
  if (!valid.length) { alert(t('alert.noRestorable')); return; }
  if (!confirm(t('confirm.restore', valid.length))) return;
  const granted = await ensureWritePermission(rootHandle);
  if (!granted) { alert(t('alert.noWritePerm')); return; }
  hideHoverPreview(); hideCtxMenu();
  let done = 0, failed = 0;
  for (let i = 0; i < valid.length; i++) {
    const item = valid[i];
    statusEl.textContent = t('status.restoring', i + 1, valid.length, item.originalName);
    try {
      const parts = item.originalRelPath.split('/');
      const origName = parts.pop();
      let dir = rootHandle;
      for (const part of parts) {
        dir = await dir.getDirectoryHandle(part, { create: true });
      }
      const finalName = await getUniqueName(dir, origName);
      const blob = await item.fileHandle.getFile();
      const fh = await dir.getFileHandle(finalName, { create: true });
      const w = await fh.createWritable();
      await w.write(blob);
      await w.close();
      await item.parentHandle.removeEntry(item.trashName);
      done++;
    } catch (e) {
      console.error('Restore failed:', item.path, e);
      failed++;
    }
  }
  statusEl.textContent = failed
    ? t('status.restoredWithFail', done, failed)
    : t('status.restored', done);
  await rebuildTree();
}
async function purgeTrashItems(items) {
  if (!settings.allowDelete) { alert(t('alert.deleteDisabled')); return; }
  items = [...items];
  if (!items.length) return;
  if (!confirm(t('confirm.purge', items.length))) return;
  hideHoverPreview(); hideCtxMenu();
  let done = 0, failed = 0;
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    statusEl.textContent = t('status.purging', i + 1, items.length, item.name);
    try {
      await item.parentHandle.removeEntry(item.trashName);
      thumbCache.delete(item.path);
      const u = previewUrlCache.get(item.path);
      if (u) { URL.revokeObjectURL(u); previewUrlCache.delete(item.path); }
      done++;
    } catch (e) {
      console.error('Purge failed:', item.path, e);
      failed++;
    }
  }
  statusEl.textContent = failed
    ? t('status.purgedWithFail', done, failed)
    : t('status.purged', done);
  resetSelectionSilently();
  if (selectedNode && selectedNode.isTrash) await renderGrid(selectedNode);
}

/* ============================================================
   普通删除
   ============================================================ */
async function deleteFiles(fileList) {
  if (!settings.allowDelete) { alert(t('alert.deleteDisabled')); return; }
  fileList = [...new Map(fileList.map(f => [f.path, f])).values()];
  if (!fileList.length) return;
  const isTrash = settings.deleteMode === 'trash';
  const confirmMsg = isTrash
    ? t('confirm.deleteTrash', fileList.length)
    : t('confirm.deletePermanent', fileList.length);
  if (!confirm(confirmMsg)) return;
  hideHoverPreview(); hideCtxMenu();
  const dirs = [...new Set(fileList.map(f => f.parentHandle))];
  for (const d of dirs) {
    const granted = await ensureWritePermission(d);
    if (!granted) { alert(t('alert.noWritePermDelete')); return; }
  }
  let trashDir = null;
  if (isTrash) {
    trashDir = await getTrashDir(true);
    if (!trashDir) { alert(t('alert.cantCreateTrash')); return; }
  }
  let done = 0, failed = 0;
  const total = fileList.length;
  for (let i = 0; i < total; i++) {
    const f = fileList[i];
    statusEl.textContent = isTrash
      ? t('status.movingToTrash', i + 1, total, f.name)
      : t('status.deleting', i + 1, total, f.name);
    try {
      if (isTrash) await moveToTrash(f, trashDir);
      else await f.parentHandle.removeEntry(f.name);
      thumbCache.delete(f.path);
      const u = previewUrlCache.get(f.path);
      if (u) { URL.revokeObjectURL(u); previewUrlCache.delete(f.path); }
      if (f.parentNode) {
        const idx = f.parentNode.files.indexOf(f);
        if (idx >= 0) f.parentNode.files.splice(idx, 1);
      }
      done++;
    } catch (err) {
      console.error('Delete failed:', f.path, err);
      failed++;
    }
  }
  if (treeRoot) { recomputeTotals(treeRoot); refreshTreeCounts(treeRoot); }
  resetSelectionSilently();
  const verb = isTrash ? t('status.movedToTrash', done) : t('status.deleted', done);
  statusEl.textContent = failed
    ? t('status.deletedWithFail', verb, failed)
    : verb;
  if (selectedNode) await renderGrid(selectedNode);
}
async function deleteCurrentFromLightbox() {
  if (!settings.allowDelete) return;
  const file = currentFiles[currentIndex];
  if (!file) return;
  const idxBefore = currentIndex;
  const before = currentFiles.length;
  if (viewMode === 'trash') await purgeTrashItems([file]);
  else await deleteFiles([file]);
  if (!lightbox.classList.contains('open')) return;
  if (currentFiles.length === before) return;
  if (currentFiles.length === 0) { closeLightbox(); return; }
  const newIdx = Math.min(idxBefore, currentFiles.length - 1);
  showImage(currentFiles, newIdx);
}

/* ============================================================
   右键菜单
   ============================================================ */
let ctxFile = null, ctxIdx = -1;
function hideCtxMenu() {
  ctxMenu.classList.add('hidden');
  ctxMenu.innerHTML = '';
  ctxFile = null; ctxIdx = -1;
}
function buildCtxMenu(isTrashView) {
  ctxMenu.innerHTML = '';
  const addItem = (text, act, cls) => {
    const el = document.createElement('div');
    el.className = 'ctx-item' + (cls ? ' ' + cls : '');
    el.textContent = text;
    el.dataset.act = act;
    ctxMenu.appendChild(el);
  };
  const addSep = () => {
    const el = document.createElement('div');
    el.className = 'ctx-sep';
    ctxMenu.appendChild(el);
  };
  addItem(t('ctx.view'), 'view');
  if (isTrashView) {
    if (settings.allowRestore || settings.allowDelete) addSep();
    if (settings.allowRestore) {
      if (ctxFile.restorable) addItem(t('ctx.restore'), 'restore', 'restore');
      else addItem(t('ctx.restoreNoInfo'), 'restore-disabled', 'disabled');
    }
    if (settings.allowDelete) {
      if (settings.allowRestore) addSep();
      addItem(t('ctx.permanentDelete'), 'purge', 'danger');
    }
  } else {
    addItem(t('ctx.select'), 'select');
    if (settings.allowDelete) {
      addSep();
      addItem(
        settings.deleteMode === 'trash' ? t('ctx.moveToTrash') : t('ctx.delete'),
        'delete', 'danger'
      );
    }
  }
}
function showCtxMenu(x, y) {
  ctxMenu.classList.remove('hidden');
  ctxMenu.style.left = '0px';
  ctxMenu.style.top = '0px';
  const r = ctxMenu.getBoundingClientRect();
  let left = x, top = y;
  if (left + r.width > window.innerWidth - 8) left = window.innerWidth - r.width - 8;
  if (top + r.height > window.innerHeight - 8) top = window.innerHeight - r.height - 8;
  ctxMenu.style.left = Math.max(8, left) + 'px';
  ctxMenu.style.top  = Math.max(8, top) + 'px';
}
grid.addEventListener('contextmenu', e => {
  const item = e.target.closest('.thumb-item');
  if (!item || !item._file) return;
  e.preventDefault();
  hideHoverPreview();
  ctxFile = item._file;
  ctxIdx = currentFiles.indexOf(ctxFile);
  buildCtxMenu(viewMode === 'trash');
  showCtxMenu(e.clientX, e.clientY);
});
ctxMenu.addEventListener('click', e => {
  e.stopPropagation();
  const act = e.target.dataset.act;
  if (!act || !ctxFile) return;
  const file = ctxFile, idx = ctxIdx;
  hideCtxMenu();
  if (act === 'view') openLightbox(currentFiles, idx);
  else if (act === 'select') {
    selectionMode = true;
    selectedPaths.add(file.path);
    const el = [...grid.querySelectorAll('.thumb-item')].find(x => x._file === file);
    if (el) { el.classList.add('selected'); if (el._check) el._check.checked = true; }
    updateSelectionUI();
  } else if (act === 'delete') {
    if (settings.allowDelete) deleteFiles([file]);
  } else if (act === 'restore') {
    if (settings.allowRestore && file.restorable) restoreTrashItems([file]);
  } else if (act === 'purge') {
    if (settings.allowDelete) purgeTrashItems([file]);
  }
});
window.addEventListener('click', hideCtxMenu);
contentEl.addEventListener('scroll', hideCtxMenu, { passive: true });
window.addEventListener('resize', hideCtxMenu);

/* ============================================================
   渲染网格
   ============================================================ */
async function renderGrid(node) {
  hideHoverPreview(); hideCtxMenu();
  resetSelectionSilently();
  const token = ++renderToken;
  const isTrash = !!node.isTrash;
  viewMode = isTrash ? 'trash' : 'normal';
  crumbEl.textContent = isTrash ? '🗑 ' + t('tree.trash') : (node.path || (treeRoot ? treeRoot.name : ''));

  let files;
  if (isTrash) {
    placeholder.classList.remove('hidden');
    grid.classList.add('hidden');
    placeholder.textContent = t('ph.trashReading');
    headMeta.textContent = '';
    const trashDir = await getTrashDir(false);
    if (token !== renderToken) return;
    if (!trashDir) {
      currentFiles = [];
      placeholder.textContent = t('ph.trashEmpty');
      headMeta.textContent = t('head.count', 0);
      return;
    }
    files = await scanTrash(trashDir);
    if (token !== renderToken) return;
    files = files.filter(f => isMediaEnabled(f.originalName || f.name));
    files.sort((a, b) => (b.deletedAt || 0) - (a.deletedAt || 0));
  } else {
    const includeChildren = includeSub.checked;
    files = includeChildren ? collectAllFiles(node) : node.files.slice();
    files = files.filter(f => isMediaEnabled(f.name));
  }
  currentFiles = files;
  currentIndex = -1;

  headMeta.textContent = files.length
    ? (isTrash ? t('head.countRestore', files.length)
       : (includeSub.checked ? t('head.countSub', files.length) : t('head.countCur', files.length)))
    : t('head.noContent');

  if (!files.length) {
    grid.innerHTML = '';
    grid.classList.add('hidden');
    placeholder.classList.remove('hidden');
    if (settings.enabledExts.length === 0) {
      placeholder.textContent = t('ph.noTypes');
    } else if (isTrash) {
      placeholder.textContent = t('ph.trashEmpty2');
    } else if (node.children.length) {
      placeholder.textContent = t('ph.emptyFolderSub');
    } else {
      placeholder.textContent = t('ph.emptyFolder');
    }
    return;
  }
  placeholder.classList.add('hidden');
  grid.classList.remove('hidden');
  if (currentObserver) { currentObserver.disconnect(); currentObserver = null; }
  grid.innerHTML = '';
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const el = entry.target;
      observer.unobserve(el);
      loadThumb(el);
    }
  }, { root: contentEl, rootMargin: '300px' });
  currentObserver = observer;
  let i = 0;
  const BATCH = 120;
  function insertBatch() {
    if (token !== renderToken) return;
    const end = Math.min(i + BATCH, files.length);
    const frag = document.createDocumentFragment();
    for (; i < end; i++) {
      const file = files[i];
      const idx = i;
      const kind = getMediaKind(file.name) || 'image';

      const item = document.createElement('div');
      item.className = 'thumb-item thumb-loading';
      item._file = file;

      const check = document.createElement('input');
      check.type = 'checkbox';
      check.className = 'thumb-check';
      check.addEventListener('click', ev => ev.stopPropagation());
      check.addEventListener('change', () => {
        if (check.checked) selectedPaths.add(file.path);
        else selectedPaths.delete(file.path);
        item.classList.toggle('selected', check.checked);
        if (check.checked) selectionMode = true;
        hideHoverPreview();
        updateSelectionUI();
      });
      item._check = check;
      item.appendChild(check);

      if (kind === 'image') {
        const img = document.createElement('img');
        img.alt = file.name;
        item._img = img; item._kind = 'image';
        item.appendChild(img);
      } else if (kind === 'video') {
        const video = document.createElement('video');
        video.muted = true; video.playsInline = true;
        video.preload = 'metadata'; video.disablePictureInPicture = true;
        item._video = video; item._kind = 'video';
        item.appendChild(video);
        const badge = document.createElement('div');
        badge.className = 'play-badge';
        badge.innerHTML = '<span>▶</span>';
        item.appendChild(badge);
      } else {
        const ph = document.createElement('div');
        ph.className = 'media-placeholder';
        ph.innerHTML = `<div class="media-icon">🎵</div><div class="media-ext">${EXT_INDEX[String(file.name.split('.').pop()).toLowerCase()].label}</div>`;
        item._kind = 'audio';
        item.appendChild(ph);
        const badge = document.createElement('div');
        badge.className = 'play-badge';
        badge.innerHTML = '<span>▶</span>';
        item.appendChild(badge);
      }

      if (kind !== 'image') {
        const kb = document.createElement('span');
        kb.className = 'thumb-kind ' + kind;
        kb.textContent = MEDIA_TYPES[kind].label;
        item.appendChild(kb);
      }

      if (isTrash && file.originalRelPath) {
        const orig = document.createElement('span');
        orig.className = 'thumb-orig';
        orig.textContent = file.originalRelPath;
        orig.title = file.originalRelPath;
        item.appendChild(orig);
      }

      const label = document.createElement('span');
      label.className = 'thumb-label';
      label.textContent = isTrash && file.originalName ? file.originalName : file.name;
      item.appendChild(label);

      item.addEventListener('click', () => {
        if (selectionMode) {
          check.checked = !check.checked;
          check.dispatchEvent(new Event('change'));
          return;
        }
        hideHoverPreview(); hideCtxMenu();
        currentIndex = idx;
        openLightbox(files, idx);
      });

      frag.appendChild(item);
      observer.observe(item);
    }
    grid.appendChild(frag);
    if (i < files.length) requestAnimationFrame(insertBatch);
  }
  insertBatch();
  contentEl.scrollTop = 0;
}

/* ============================================================
   缩略图
   ============================================================ */
async function makeImageThumbnail(file, maxSize) {
  try {
    const bitmap = await createImageBitmap(file);
    const ratio = Math.min(1, maxSize / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * ratio));
    const h = Math.max(1, Math.round(bitmap.height * ratio));
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
    if (bitmap.close) bitmap.close();
    return canvas.toDataURL('image/jpeg', 0.78);
  } catch (err) {
    return URL.createObjectURL(file);
  }
}
async function loadThumb(item) {
  const file = item._file;
  const kind = item._kind;
  try {
    if (kind === 'image') {
      let url = thumbCache.get(file.path);
      if (!url) {
        const f = await file.fileHandle.getFile();
        url = await makeImageThumbnail(f, settings.thumbRes);
        thumbCache.set(file.path, url);
      }
      item._img.src = url;
      item._img.classList.add('loaded');
      item.classList.remove('thumb-loading');
      return;
    }
    if (kind === 'video') {
      const f = await file.fileHandle.getFile();
      const url = URL.createObjectURL(f);
      const video = item._video;
      let cleaned = false;
      const cleanup = () => { if (!cleaned) { cleaned = true; URL.revokeObjectURL(url); } };
      video.addEventListener('loadeddata', () => {
        video.classList.add('loaded');
        item.classList.remove('thumb-loading');
      }, { once: true });
      video.addEventListener('error', () => {
        cleanup();
        item.classList.remove('thumb-loading');
        const ph = document.createElement('div');
        ph.className = 'media-placeholder';
        const ext = String(file.name.split('.').pop()).toUpperCase();
        ph.innerHTML = `<div class="media-icon">🎬</div><div class="media-ext">${ext}</div>`;
        item.insertBefore(ph, item.firstChild);
        if (item._video) { item._video.remove(); item._video = null; }
      }, { once: true });
      video.src = url;
      return;
    }
    item.classList.remove('thumb-loading');
  } catch (err) {
    console.warn('Thumbnail failed:', file.path, err);
    item.classList.remove('thumb-loading');
  }
}

/* ============================================================
   灯箱
   ============================================================ */
let scale = 1, panX = 0, panY = 0;
let dragging = false, dragStartX = 0, dragStartY = 0, startPanX = 0, startPanY = 0;
let lbToken = 0;
let currentUrlToRevoke = null;

function applyTransform() {
  lbImg.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
}
function resetTransform() { scale = 1; panX = 0; panY = 0; applyTransform(); }
function revokeCurrentMediaUrl() {
  if (currentUrlToRevoke) {
    try { URL.revokeObjectURL(currentUrlToRevoke); } catch (e) {}
    currentUrlToRevoke = null;
  }
}

let slideshowTimer = null;
function stopSlideshow() {
  if (slideshowTimer) { clearTimeout(slideshowTimer); slideshowTimer = null; }
}
function scheduleSlideshow() {
  stopSlideshow();
  if (!settings.slideshow) return;
  if (!lightbox.classList.contains('open')) return;
  if (currentFiles.length <= 1) return;
  const file = currentFiles[currentIndex];
  if (!file) return;
  const kind = getMediaKind(file.name) || 'image';
  if (kind === 'video' && lbVideo.src && !lbVideo.paused && !lbVideo.ended) return;
  if (kind === 'audio' && lbAudio.src && !lbAudio.paused && !lbAudio.ended) return;
  slideshowTimer = setTimeout(() => { navigate(1); },
    Math.max(1, settings.slideshowInterval) * 1000);
}
function syncSlideshowBtn() {
  if (settings.slideshow) {
    lbSlideshowBtn.classList.add('active');
    lbSsIcon.textContent = '⏸';
    lbSlideshowBtn.title = t('lb.slideshowOn');
  } else {
    lbSlideshowBtn.classList.remove('active');
    lbSsIcon.textContent = '▶';
    lbSlideshowBtn.title = t('lb.slideshowOff');
  }
}
function setSlideshow(enabled) {
  settings.slideshow = !!enabled;
  saveSettings();
  inputs.slideshow.checked = settings.slideshow;
  updateDeleteSettingsUI();
  syncSlideshowBtn();
  if (!settings.slideshow) { stopSlideshow(); return; }
  if (!lightbox.classList.contains('open')) return;
  const file = currentFiles[currentIndex];
  if (file) {
    const kind = getMediaKind(file.name) || 'image';
    if (kind === 'video' && lbVideo.src && lbVideo.paused) {
      const p = lbVideo.play(); if (p && p.catch) p.catch(() => {});
    } else if (kind === 'audio' && lbAudio.src && lbAudio.paused) {
      const p = lbAudio.play(); if (p && p.catch) p.catch(() => {});
    }
  }
  scheduleSlideshow();
}
lbSlideshowBtn.addEventListener('click', e => {
  e.stopPropagation();
  setSlideshow(!settings.slideshow);
});

function openLightbox(files, idx) {
  hideHoverPreview(); hideCtxMenu();
  lightbox.classList.add('open');
  syncSlideshowBtn();
  showImage(files, idx);
}
function closeLightbox() {
  stopSlideshow();
  lightbox.classList.remove('open');
  lbImg.src = '';
  lbVideo.pause(); lbVideo.removeAttribute('src'); lbVideo.load();
  lbAudio.pause(); lbAudio.removeAttribute('src'); lbAudio.load();
  revokeCurrentMediaUrl();
  resetTransform();
  lbBottom.textContent = t('lb.imageHint');
  lbToken++;
}
function updateNavButtons() {
  const hide = currentFiles.length <= 1;
  lbPrev.classList.toggle('hidden', hide);
  lbNext.classList.toggle('hidden', hide);
}
function switchLightboxMode(mode) {
  lbImg.classList.toggle('hidden', mode !== 'image');
  lbVideo.classList.toggle('hidden', mode !== 'video');
  lbAudioWrap.classList.toggle('hidden', mode !== 'audio');
}

async function showImage(files, idx) {
  const file = files[idx];
  if (!file) return;
  stopSlideshow();
  revokeCurrentMediaUrl();
  const token = ++lbToken;
  currentIndex = idx; currentFiles = files;
  updateNavButtons();
  resetTransform();

  lbVideo.pause(); lbVideo.removeAttribute('src'); lbVideo.load();
  lbAudio.pause(); lbAudio.removeAttribute('src'); lbAudio.load();

  const kind = getMediaKind(file.name) || 'image';
  const displayName = (viewMode === 'trash' && file.originalName) ? file.originalName : file.name;
  const suffix = (viewMode === 'trash' && file.originalRelPath) ? t('lb.origSuffix', file.originalRelPath) : '';
  lbTitle.textContent = `${idx + 1} / ${files.length} · ${displayName}${suffix}`;

  const shouldAutoPlay = settings.autoPlayMedia || settings.slideshow;

  if (kind === 'image') {
    switchLightboxMode('image');
    
    // 处理 EXIF / 文件信息展示
    if (settings.showExif) {
      lbBottom.textContent = '读取信息中...';
      getExifData(file).then(async (exif) => {
        if (token !== lbToken) return;
        let hasExif = false;
        if (exif) {
          const parts = [];
          if (exif.Make || exif.Model) parts.push(`📷 ${(exif.Make || '')} ${(exif.Model || '').replace(exif.Make || '', '').trim()}`.trim());
          if (exif.DateTimeOriginal) parts.push(`📅 ${exif.DateTimeOriginal.replace(/:/g, '-')}`);
          if (exif.FNumber) parts.push(`🔍 f/${exif.FNumber.toFixed(1)}`);
          if (exif.ExposureTime) {
            const s = exif.ExposureTime >= 1 ? exif.ExposureTime + 's' : '1/' + Math.round(1/exif.ExposureTime) + 's';
            parts.push(`⏱ ${s}`);
          }
          if (exif.ISO) parts.push(`🎞 ISO ${exif.ISO}`);
          if (exif.FocalLength) parts.push(`📏 ${exif.FocalLength.toFixed(0)}mm`);
          
          if (parts.length > 0) {
            hasExif = true;
            lbBottom.innerHTML = `<span style="color:rgba(255,255,255,.8);letter-spacing:0.5px">${parts.join(' &nbsp;·&nbsp; ')}</span>`;
          }
        }
        
        // 如果没有 EXIF 信息，则显示文件信息
        if (!hasExif) {
          const infoHtml = await getFileInfoHtml(file);
          if (token !== lbToken) return;
          lbBottom.innerHTML = infoHtml || t('lb.imageHint');
        }
      }).catch(async () => {
        if (token !== lbToken) return;
        const infoHtml = await getFileInfoHtml(file);
        if (token === lbToken) lbBottom.innerHTML = infoHtml || t('lb.imageHint');
      });
    } else {
      lbBottom.textContent = t('lb.imageHint');
    }

    lbImg.style.opacity = '0.25';
    try {
      const f = await file.fileHandle.getFile();
      if (token !== lbToken) return;
      const url = URL.createObjectURL(f);
      currentUrlToRevoke = url;
      lbImg.onload = () => { lbImg.style.opacity = '1'; };
      lbImg.src = url;
    } catch (err) {
      console.error(err);
      lbImg.style.opacity = '1';
      lbTitle.textContent = t('lb.imageLoadFailed', file.name);
    }
    scheduleSlideshow();
    return;
  }

  if (kind === 'video') {
    switchLightboxMode('video');
    if (settings.showExif) {
      getFileInfoHtml(file).then(html => {
        if (token === lbToken) lbBottom.innerHTML = html || t('lb.mediaHint');
      });
    } else {
      lbBottom.textContent = t('lb.mediaHint');
    }
    try {
      const f = await file.fileHandle.getFile();
      if (token !== lbToken) return;
      const url = URL.createObjectURL(f);
      currentUrlToRevoke = url;
      lbVideo.src = url;
      if (shouldAutoPlay) {
        const p = lbVideo.play(); if (p && p.catch) p.catch(() => {});
      }
    } catch (err) {
      console.error(err);
      lbTitle.textContent = t('lb.videoLoadFailed', file.name);
    }
    scheduleSlideshow();
    return;
  }

  switchLightboxMode('audio');
  if (settings.showExif) {
    getFileInfoHtml(file).then(html => {
      if (token === lbToken) lbBottom.innerHTML = html || t('lb.mediaHint');
    });
  } else {
    lbBottom.textContent = t('lb.mediaHint');
  }
  lbAudioName.textContent = displayName;
  try {
    const f = await file.fileHandle.getFile();
    if (token !== lbToken) return;
    const url = URL.createObjectURL(f);
    currentUrlToRevoke = url;
    lbAudio.src = url;
    if (shouldAutoPlay) {
      const p = lbAudio.play(); if (p && p.catch) p.catch(() => {});
    }
  } catch (err) {
    console.error(err);
    lbAudioName.textContent = t('lb.audioLoadFailed', file.name);
  }
  scheduleSlideshow();
}

function navigate(delta) {
  if (!currentFiles.length) return;
  let next = currentIndex + delta;
  if (next < 0) next = currentFiles.length - 1;
  if (next >= currentFiles.length) next = 0;
  showImage(currentFiles, next);
}
lbPrev.addEventListener('click', e => { e.stopPropagation(); navigate(-1); });
lbNext.addEventListener('click', e => { e.stopPropagation(); navigate(1); });

lbVideo.addEventListener('play', stopSlideshow);
lbVideo.addEventListener('pause', () => { if (lbVideo.src) scheduleSlideshow(); });
lbVideo.addEventListener('ended', () => { scheduleSlideshow(); });
lbAudio.addEventListener('play', stopSlideshow);
lbAudio.addEventListener('pause', () => { if (lbAudio.src) scheduleSlideshow(); });
lbAudio.addEventListener('ended', () => { scheduleSlideshow(); });

lbStage.addEventListener('wheel', e => {
  if (!lightbox.classList.contains('open')) return;
  if (lbImg.classList.contains('hidden')) return;
  e.preventDefault();
  const factor = e.deltaY > 0 ? 0.9 : 1.1;
  const nextScale = Math.min(10, Math.max(0.1, scale * factor));
  if (Math.abs(nextScale - scale) < 1e-6) return;
  const rect = lbStage.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const ratio = nextScale / scale;
  panX = e.clientX - cx - ratio * (e.clientX - cx - panX);
  panY = e.clientY - cy - ratio * (e.clientY - cy - panY);
  scale = nextScale;
  applyTransform();
}, { passive: false });

lbImg.addEventListener('mousedown', e => {
  if (!lightbox.classList.contains('open')) return;
  e.preventDefault();
  dragging = true;
  dragStartX = e.clientX; dragStartY = e.clientY;
  startPanX = panX; startPanY = panY;
  lbImg.style.cursor = 'grabbing';
});
window.addEventListener('mousemove', e => {
  if (!dragging) return;
  panX = startPanX + (e.clientX - dragStartX);
  panY = startPanY + (e.clientY - dragStartY);
  applyTransform();
});
window.addEventListener('mouseup', () => {
  if (!dragging) return;
  dragging = false; lbImg.style.cursor = '';
});
lbImg.addEventListener('dblclick', e => { e.stopPropagation(); resetTransform(); });
lbStage.addEventListener('click', e => { if (e.target === lbStage) closeLightbox(); });
lbClose.addEventListener('click', closeLightbox);
lbVideo.addEventListener('click', e => e.stopPropagation());
lbAudioWrap.addEventListener('click', e => e.stopPropagation());

/* ============================================================
   键盘
   ============================================================ */
window.addEventListener('keydown', e => {
  if (settingsModal.classList.contains('open')) {
    if (e.key === 'Escape') settingsModal.classList.remove('open');
    return;
  }

  const el = e.target;
  const isTextInput = el && (
    el.isContentEditable ||
    el.tagName === 'TEXTAREA' ||
    (el.tagName === 'INPUT' && !['checkbox', 'radio', 'range', 'button', 'submit'].includes(el.type))
  );

  if ((e.key === 'Delete' || e.key === 'Backspace') && !isTextInput) {
    if (lightbox.classList.contains('open')) {
      if (!settings.allowDelete) return;
      e.preventDefault();
      deleteCurrentFromLightbox();
      return;
    }
    if (settings.allowDelete && selectionMode && selectedPaths.size > 0) {
      e.preventDefault();
      const list = currentFiles.filter(f => selectedPaths.has(f.path));
      if (list.length) {
        if (viewMode === 'trash') purgeTrashItems(list);
        else deleteFiles(list);
      }
      return;
    }
    return;
  }

  if (!lightbox.classList.contains('open')) {
    if (e.key === 'Escape') hideCtxMenu();
    return;
  }

  if (e.key === 'Escape') {
    e.preventDefault();
    closeLightbox();
    return;
  }

  if (e.key === ' ' || e.key === 'Enter' || e.key === 'Spacebar') {
    const file = currentFiles[currentIndex];
    if (!file) return;
    const kind = getMediaKind(file.name) || 'image';

    if (kind === 'video' || kind === 'audio') {
      e.preventDefault();
      if (kind === 'video') {
        if (lbVideo.paused) { const p = lbVideo.play(); if (p && p.catch) p.catch(() => {}); }
        else lbVideo.pause();
      } else {
        if (lbAudio.paused) { const p = lbAudio.play(); if (p && p.catch) p.catch(() => {}); }
        else lbAudio.pause();
      }
      return;
    }

    const focused = document.activeElement;
    const isInteractive = focused && (
      focused.tagName === 'BUTTON' ||
      focused.tagName === 'A' ||
      (focused.tagName === 'INPUT' && ['button','submit','checkbox','radio'].includes(focused.type))
    );
    if (isInteractive) return;
    e.preventDefault();
    navigate(1);
    return;
  }

  const focused = document.activeElement;
  const onMediaElement = focused === lbVideo || focused === lbAudio;
  if (e.key === 'ArrowRight') {
    if (onMediaElement) return;
    e.preventDefault();
    navigate(1);
  } else if (e.key === 'ArrowLeft') {
    if (onMediaElement) return;
    e.preventDefault();
    navigate(-1);
  }
});

/* ============================================================
   展开 / 折叠
   ============================================================ */
includeSub.addEventListener('change', () => {
  if (selectedNode) renderGrid(selectedNode);
});
function setAllExpanded(expanded) {
  if (!treeRoot) return;
  (function walk(n) {
    n.expanded = expanded;
    if (n._childrenEl) n._childrenEl.classList.toggle('hidden', !expanded);
    if (n._toggle) n._toggle.textContent = n.children.length ? (expanded ? '▾' : '▸') : '';
    n.children.forEach(walk);
  })(treeRoot);
}
expandAllBtn.addEventListener('click', () => setAllExpanded(true));
collapseAllBtn.addEventListener('click', () => setAllExpanded(false));

/* ============================================================
   选择文件夹
   ============================================================ */
pickBtn.addEventListener('click', async () => {
  if (!('showDirectoryPicker' in window)) {
    alert(t('alert.noApi'));
    return;
  }
  let dirHandle;
  try {
    dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
  } catch (err) {
    if (err.name === 'AbortError') statusEl.textContent = t('status.canceled');
    return;
  }
  try {
    pickBtn.disabled = true;
    hideHoverPreview(); hideCtxMenu();
    thumbCache.clear(); clearPreviewUrlCache();
    resetSelectionSilently();
    scannedDirs = 0;
    treeEl.innerHTML = '';
    grid.innerHTML = '';
    grid.classList.add('hidden');
    placeholder.classList.remove('hidden');
    placeholder.textContent = t('ph.scanning');
    crumbEl.textContent = dirHandle.name;
    headMeta.textContent = '';
    statusEl.textContent = t('status.startScan');
    rootHandle = dirHandle;
    trashDirHandle = null;
    viewMode = 'normal';
    treeRoot = await buildTree(dirHandle, dirHandle.name, '', 0);
    updateAllTotals(treeRoot);
    treeRoot.expanded = true;
    renderTree();
    treeActions.classList.remove('hidden');
    if (treeRoot.total === 0) {
      placeholder.textContent = settings.enabledExts.length === 0
        ? t('ph.noTypes')
        : t('ph.noFile');
      statusEl.textContent = t('status.noFileFound');
      if (settings.showTrash) selectTrashNode();
    } else {
      statusEl.textContent = t('status.scanDone', treeRoot.total, countDirs(treeRoot));
      selectNode(treeRoot);
    }
  } catch (err) {
    console.error(err);
    statusEl.textContent = t('status.readFailed', err.message);
    placeholder.textContent = t('status.readFailed', err.message);
  } finally {
    pickBtn.disabled = false;
  }
});
function countDirs(node) {
  let n = 1;
  for (const c of node.children) n += countDirs(c);
  return n;
}

/* ============================================================
   初始化
   ============================================================ */
document.documentElement.setAttribute('data-theme', settings.theme);
applyI18n();
buildExtCheckboxes();
applyTileSize();
syncSettingsUI();
updateSelectionUI();
syncThemeMenu();
syncLangMenu();
syncSlideshowBtn();

})();